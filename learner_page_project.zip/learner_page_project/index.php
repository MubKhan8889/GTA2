<?php
// Sample learner data (Replace with database queries as needed)
$learner = [
    'name' => 'Learner Name',
    'tutor' => 'Tutor Name',
    'apprenticeship_type' => 'OTJ in log, to date',
    'employer_name' => 'Progress RAG',
    'start_date' => 'Employment RAG',
    'end_date' => 'Current Position',
    'day_release' => 'Scheduled Day',
    'key_modules' => [
        'Year 1' => [
            'Group 1: Foundation Skills',
            'Group 2: Tools & Equipment',
            'Group 3: Diversity Training',
            'Group 4: Paint/Sealant & Substrate Prep',
            'Group 6: Working with plastic components',
            'Maths L2',
            'English L2',
            'Gateway 1'
        ],
        'Year 2 & 3' => [
            'Group 5: Applying Masking Material',
            'Group 6: Applying Paints',
            'Group 7: Identify & Rectify Paint Defects',
            'Gateway 2',
            'End Point Assessment (EPA)'
        ]
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learner Page</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .container {
            display: flex;
            gap: 20px;
            padding: 20px;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: white;
            padding: 20px;
            min-height: 100vh;
        }
        .sidebar ul li {
            padding: 20px 10px;
            margin-bottom: 15px;
        }
        .content {
            flex: 1;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .details {
            background: #f4f4f4;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .modules {
            display: flex;
            justify-content: space-between;
        }
        .modules ul {
            list-style: none;
            padding: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <aside class="sidebar">
            <h2>GTA logo here</h2>
            <ul>
                <li>Dashboard</li>
                <li>Apprentice Progress</li>
                <li>Edit Apprentice Info</li>
                <li>Archive Learners</li>
            </ul>
        </aside>
        <main class="content">
            <h1>Learner Page</h1>
            <div class="details">
                <p><strong>Name:</strong> <?= $learner['name'] ?></p>
                <p><strong>Tutor:</strong> <?= $learner['tutor'] ?></p>
                <p><strong>Apprenticeship Type:</strong> <?= $learner['apprenticeship_type'] ?></p>
                <p><strong>Employer Name:</strong> <?= $learner['employer_name'] ?></p>
                <p><strong>Start Date:</strong> <?= $learner['start_date'] ?></p>
                <p><strong>Actual Finish Date:</strong> <?= $learner['end_date'] ?></p>
                <p><strong>Day Release:</strong> <?= $learner['day_release'] ?></p>
            </div>
            <div class="modules">
                <div>
                    <h2>Year 1</h2>
                    <ul>
                        <?php foreach ($learner['key_modules']['Year 1'] as $module): ?>
                            <li><?= $module ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div>
                    <h2>Year 2 & 3</h2>
                    <ul>
                        <?php foreach ($learner['key_modules']['Year 2 & 3'] as $module): ?>
                            <li><?= $module ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
