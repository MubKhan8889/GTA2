<?php
  // Sample Data (Normally this would be fetched from a database)
  $tutor_name = "Tutor Name";
  $progress_rag = "#90EE90";
  $otj_rag = "#ADFF2F";
  $employment_rag = "#FF6347";
  
  $in_progress_duties = [
    "Group 1: Foundation Skills",
    "Group 1: Vehicle trim and panel components",
    "Starting and charging systems"
  ];

  $overdue_duties = [
    "Group 5: Steering and Suspension",
    "Group 8: Transmission and Driveline",
    "Gateway 2"
  ];

  $hours_this_month = [
    "Training Center" => 12.2,
    "Employer" => 8.5,
    "Specialist Training" => 0,
    "VLE Training" => 2.8,
    "Total" => 23.5
  ];

  $hours_total = [
    "Training Center" => 65.4,
    "Employer" => 32.2,
    "Specialist Training" => 16.5,
    "VLE Training" => 42.9,
    "Total" => 176.8,
    "Expected" => 150
  ];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutor Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            display: flex;
            height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: #e4e4e4;
            padding: 20px;
        }
        .sidebar h2 {
            font-size: 16px;
        }
        .menu ul {
            list-style: none;
            padding: 0;
        }
        .menu li {
            padding: 10px;
            background: #ddd;
            margin: 5px 0;
            cursor: pointer;
        }
        .content {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .dashboard-container {
            background: white;
            padding: 20px;
            width: 80%;
            max-width: 800px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .rag-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }
        .rag-box {
            width: 100px;
            padding: 5px;
            margin: 2px 0;
            color: black;
            text-align: center;
            font-weight: bold;
            border: 1px solid #000;
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        section h3 {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>GTA logo here</h2>
            <h2><?php echo $tutor_name; ?></h2>
            <div class="menu">
                <ul>
                    <li>Dashboard</li>
                    <li>Apprentice progress</li>
                    <li>Edit apprentice info</li>
                    <li>Archive learners</li>
                </ul>
            </div>
        </div>
        <div class="content">
            <div class="dashboard-container">
                <h2>Welcome, <?php echo $tutor_name; ?></h2>
                <div class="dashboard-grid">
                    <section>
                        <h3>Overall Learner RAG</h3>
                        <div class="rag-container">
                            <div class="rag-box" style="background-color: <?php echo $progress_rag; ?>">Progress RAG</div>
                            <div class="rag-box" style="background-color: <?php echo $otj_rag; ?>">OTJ RAG</div>
                            <div class="rag-box" style="background-color: <?php echo $employment_rag; ?>">Employment RAG</div>
                        </div>
                    </section>
                    <section>
                        <h3>Overall hours this month</h3>
                        <ul>
                            <?php foreach ($hours_this_month as $key => $value) { echo "<li>$key: $value</li>"; } ?>
                        </ul>
                    </section>
                    <section>
                        <h3><a href="#" style="text-decoration: none; color: blue;">Overall In Progress Duties</a></h3>
                        <ul>
                            <?php foreach ($in_progress_duties as $duty) { echo "<li>$duty</li>"; } ?>
                        </ul>
                    </section>
                    <section>
                        <h3>Overall hours in total</h3>
                        <ul>
                            <?php foreach ($hours_total as $key => $value) { echo "<li>$key: $value</li>"; } ?>
                        </ul>
                    </section>
                    <section>
                        <h3>Overall Overdue Duties</h3>
                        <ul>
                            <?php foreach ($overdue_duties as $duty) { echo "<li>$duty</li>"; } ?>
                        </ul>
                    </section>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
